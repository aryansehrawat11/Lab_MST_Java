import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try{
            System.out.println("Enter Current Balance: ");
            String balanceInput = sc.nextLine();
            double balance = Double.parseDouble(balanceInput);

            System.out.println("Enter Withdraw Amount: ");
            String withdrawAmount = sc.nextLine();
            double withdraw = Double.parseDouble(withdrawAmount);

            if(withdraw<=0){
                System.out.println("Invalid Input. Must be Positive.");
            } else if (withdraw%100 != 0){
                System.out.println("Withdrawal Amount must be multiple of 100.");
            } else if (withdraw > balance){
                System.out.println("Insufficient Balance.");
            } else{
                balance -= withdraw;
                System.out.println("Withdraw Successful.");
                System.out.println("Current Balance: " + balance);
            }
        }
        
        catch(NumberFormatException e){
            System.out.println("Invalid Input. Enter a numeric value.");
        }
        catch(Exception e){
            System.out.println("Invalid Input. Enter a numeric value.");
        }
        sc.close();
    }
}